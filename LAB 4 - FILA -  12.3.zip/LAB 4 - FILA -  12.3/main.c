//Isabella rubio venancio - 10778364
//Estrutura de dados 1
//Laboratorio 4 - 12.3.26

#include <stdio.h>
#include <stdlib.h>
#include "queue.h"

void executarProcessos(Queue *fila, int quantum) { // realiza os processos de subtração e calculo dos tempos de cada processo 

    imprimirFila(fila);

    while (!isEmpty(fila)) {

        int processo = dequeue(fila);

        if (processo > quantum) { //se o numero do processo for maior que quantum, vai precisar de mais tempo

            int novo = processo - quantum;

            printf("%d-%d = %d\n", processo, quantum, novo);
            printf("Executando o processo %d...\n", processo);
            printf("Nao finalizado! Novo valor: %d.\n", novo);

            enqueue(fila, novo);
        }
        else { // caso o tempo restante seja menor ou igual ao quantum
 
            printf("%d -> finalizou\n", processo);
            printf("Executando o processo %d...\n", processo);
            printf("Processo concluido!\n");
        }

        imprimirFila(fila);
    }
}

void imprimirFila(Queue *q) { //imprime a fila 

    printf("[");

    for (int i = 0; i < q->curr_size; i++) { //percorre a fila ate o tamanho atual dela 

        int pos = (q->inicio + i) % q->max_size;
        printf("%d", q->v[pos]);

        if (i < q->curr_size - 1)
            printf(",");
    }

    printf("]\n");
}

int main() { //funcao principal 

    int n;
    int quantum;

	printf("tamanho da fila: ");
    scanf("%d", &n);

    Queue *fila = CriaQueue(n);

    for (int i = 0; i < n; i++) {
        int tempo;
        scanf("%d", &tempo);
        enqueue(fila, tempo);
    }

    scanf("%d", &quantum);

    executarProcessos(fila, quantum);

    DestroiQueue(fila);

    return 0;
}