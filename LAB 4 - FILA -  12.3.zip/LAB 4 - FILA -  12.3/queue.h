#ifndef QUEUE_H
#define QUEUE_H

typedef struct {
    int *v;
    int inicio;
    int fim;
    int curr_size;
    int max_size;
} Queue;

Queue* CriaQueue(int tamanho);

void DestroiQueue(Queue *q);

int isEmpty(Queue *q);

int isFull(Queue *q);

int enqueue(Queue *q, int elemento);

int dequeue(Queue *q);

int front(Queue *q);

int rear(Queue *q);

int sizeElements(Queue *q);

#endif