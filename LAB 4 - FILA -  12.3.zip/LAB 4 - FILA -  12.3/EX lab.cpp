#include <stdio.h>
#include <stdlib.h>
#include "queue.h"


void executarProcessos(Queue *fila, int quantum) {

    while (!isEmpty(fila)) {

        int processo = dequeue(fila);

        printf("Executando o processo %d...\n", processo);

        processo = processo - quantum;

        if (processo <= 0) {
            printf("Processo concluido!\n");
        } 
        else {
            printf("Nao finalizado! Novo valor: %d\n", processo);
            enqueue(fila, processo);
        }
    }
}

int main() {

    int n;
    int quantum;

    scanf("%d", &n);

    Queue *fila = CriaQueue(n);

    for (int i = 0; i < n; i++) {
        int tempo;
        scanf("%d", &tempo);
        enqueue(fila, tempo);
    }

    scanf("%d", &quantum);

    executarProcessos(fila, quantum);

    DestroiQueue(fila);

    return 0;
}