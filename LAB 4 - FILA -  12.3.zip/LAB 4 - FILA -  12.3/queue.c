#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include "queue.h"

Queue* CriaQueue(int tamanho) {
    Queue *aux = malloc(sizeof(Queue));
    aux->v = malloc(tamanho * sizeof(int));
    aux->inicio = 0;
    aux->fim = 0;
    aux->curr_size = 0;
    aux->max_size = tamanho;
    return aux;
}

void DestroiQueue(Queue *q) {
    free(q->v);
    free(q);
}

int isEmpty(Queue *q) {
    return q->curr_size == 0;
}

int isFull(Queue *q) {
    return q->curr_size == q->max_size;
}

int enqueue(Queue *q, int elemento) {
    if (isFull(q)) {
    printf("Fila está cheia!\n");
    return 0;
	}

    q->v[q->fim] = elemento;
    q->fim = (q->fim + 1) % q->max_size;
    q->curr_size++;
    return 1;
}

int dequeue(Queue *q) {
    if (isEmpty(q)) {
        printf("Fila vazia!\n");
        return -1;
    }

    int elemento = front(q);
    q->inicio = (q->inicio + 1) % q->max_size;
    q->curr_size--;
    return elemento;
}

int front(Queue *q) {
    if (isEmpty(q)){
        printf("Fila vazia!\n");
        return -1;
	}
    
	return q->v[q->inicio];
}

int rear(Queue *q) {
    if (isEmpty(q)) {
        printf("Fila vazia!\n");
        return -1;
    }

    int pos = (q->fim - 1 + q->max_size) % q->max_size;
    return q->v[pos];
}

int sizeElements(Queue *q) {
    return q->curr_size;
}